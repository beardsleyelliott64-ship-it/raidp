// language: Node.js, file: src/modules/alerts.js
// YouTube new video alerts — polls RSS every 10 min, no API key needed
const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const axios = require('axios');
const cron  = require('node-cron');
const db    = require('../utils/db');

const commands = [
  new SlashCommandBuilder()
    .setName('set-alerts')
    .setDescription('Set the channel for YouTube video alerts')
    .addChannelOption(o => o.setName('channel').setDescription('Alert channel').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .toJSON(),

  new SlashCommandBuilder()
    .setName('add-youtube')
    .setDescription('Track a YouTube channel for new video alerts')
    .addStringOption(o => o.setName('channel-id').setDescription('YouTube channel ID (UCxxxxxx)').setRequired(true))
    .addStringOption(o => o.setName('name').setDescription('Display name').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .toJSON(),

  new SlashCommandBuilder()
    .setName('remove-youtube')
    .setDescription('Stop tracking a YouTube channel')
    .addStringOption(o => o.setName('channel-id').setDescription('YouTube channel ID').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .toJSON(),

  new SlashCommandBuilder()
    .setName('alerts-list')
    .setDescription('List all tracked YouTube channels')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .toJSON(),
];

async function checkYouTube(client) {
  const channels = db.get('alerts', 'youtube', []);
  const chId     = db.get('alerts', 'channelId');
  if (!channels.length || !chId) return;

  const channel = await client.channels.fetch(chId).catch(() => null);
  if (!channel) return;

  const seenVideos = db.get('alerts', 'seenYT', []);
  const seenSet    = new Set(seenVideos);
  const newSeen    = [];

  for (const yt of channels) {
    try {
      const rss = await axios.get(
        `https://www.youtube.com/feeds/videos.xml?channel_id=${yt.id}`,
        { timeout: 10_000 }
      );
      const entries = rss.data.match(/<entry>([\s\S]*?)<\/entry>/g) ?? [];
      for (const entry of entries.slice(0, 3)) {
        const videoId = (entry.match(/<yt:videoId>(.*?)<\/yt:videoId>/) ?? [])[1];
        if (!videoId) continue;
        newSeen.push(videoId);
        if (seenSet.has(videoId)) continue;

        const title     = (entry.match(/<title>(.*?)<\/title>/)         ?? [])[1] ?? 'New Video';
        const published = (entry.match(/<published>(.*?)<\/published>/) ?? [])[1];

        const embed = new EmbedBuilder()
          .setColor(0xff0000)
          .setTitle(`▶️ New Video — ${yt.name}`)
          .setDescription(`**${title}**`)
          .setURL(`https://www.youtube.com/watch?v=${videoId}`)
          .setImage(`https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`)
          .setFooter({ text: 'YouTube' })
          .setTimestamp(published ? new Date(published) : undefined);

        await channel.send({ embeds: [embed] });
      }
    } catch (e) {
      console.error(`[alerts] YouTube ${yt.id}:`, e.message);
    }
  }

  if (newSeen.length) {
    db.set('alerts', 'seenYT', [...new Set([...seenVideos, ...newSeen])].slice(-200));
  }
}

function init(client) {
  client.on('interactionCreate', async i => {
    if (!i.isChatInputCommand()) return;

    if (i.commandName === 'set-alerts') {
      const ch = i.options.getChannel('channel');
      db.set('alerts', 'channelId', ch.id);
      return i.reply({ content: `✅ Alert channel set to <#${ch.id}>.`, ephemeral: true });
    }

    if (i.commandName === 'add-youtube') {
      const id   = i.options.getString('channel-id');
      const name = i.options.getString('name');
      const list = db.get('alerts', 'youtube', []);
      if (list.find(c => c.id === id))
        return i.reply({ content: '❌ Already tracking that channel.', ephemeral: true });
      list.push({ id, name });
      db.set('alerts', 'youtube', list);
      // seed seen so we don't spam old videos on first check
      checkYouTube(client).catch(() => {});
      return i.reply({ content: `✅ Now tracking **${name}** on YouTube.`, ephemeral: true });
    }

    if (i.commandName === 'remove-youtube') {
      const id   = i.options.getString('channel-id');
      const list = db.get('alerts', 'youtube', []).filter(c => c.id !== id);
      db.set('alerts', 'youtube', list);
      return i.reply({ content: '✅ Removed.', ephemeral: true });
    }

    if (i.commandName === 'alerts-list') {
      const youtube = db.get('alerts', 'youtube', []).map(c => `**${c.name}** — \`${c.id}\``).join('\n') || 'None';
      const chId    = db.get('alerts', 'channelId');
      const embed   = new EmbedBuilder()
        .setColor(0xff0000)
        .setTitle('▶️ YouTube Alert Tracker')
        .addFields(
          { name: 'Alert Channel', value: chId ? `<#${chId}>` : '❌ Not set', inline: false },
          { name: 'Tracked Channels', value: youtube, inline: false },
        );
      return i.reply({ embeds: [embed], ephemeral: true });
    }
  });

  // poll every 10 minutes
  cron.schedule('*/10 * * * *', () => checkYouTube(client).catch(console.error));
  console.log('[alerts] YouTube polling every 10min');
}

module.exports = { commands, init };
