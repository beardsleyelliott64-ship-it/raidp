// language: Node.js, file: src/modules/stats.js
// Fortnite: fortnite-api.com (free, no key)
// Valorant: henrikdev API (free, no key)
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');

const commands = [
  new SlashCommandBuilder()
    .setName('stats')
    .setDescription('Look up game stats')
    .addSubcommand(s => s
      .setName('fortnite')
      .setDescription('Fortnite lifetime stats')
      .addStringOption(o => o.setName('username').setDescription('Epic Games username').setRequired(true))
      .addStringOption(o => o.setName('platform').setDescription('Platform (default: epic)').setRequired(false)
        .addChoices(
          { name: 'Epic',  value: 'epic' },
          { name: 'PSN',   value: 'psn'  },
          { name: 'Xbox',  value: 'xbl'  },
        )))
    .addSubcommand(s => s
      .setName('valorant')
      .setDescription('Valorant rank and MMR')
      .addStringOption(o => o.setName('username').setDescription('Riot ID — Name#TAG').setRequired(true))
      .addStringOption(o => o.setName('region').setDescription('Region (default: eu)').setRequired(false)
        .addChoices(
          { name: 'EU', value: 'eu' },
          { name: 'NA', value: 'na' },
          { name: 'AP', value: 'ap' },
          { name: 'KR', value: 'kr' },
        )))
    .toJSON(),
];

async function fortniteStats(username, platform = 'epic') {
  const res = await axios.get('https://fortnite-api.com/v2/stats/br/v2', {
    params: { name: username, accountType: platform, timeWindow: 'lifetime', image: 'all' },
    timeout: 15_000,
  });
  return res.data?.data;
}

async function valorantStats(riotId, region = 'eu') {
  const [name, tag] = riotId.split('#');
  if (!tag) throw new Error('Use format Name#TAG e.g. Player#1234');
  const res = await axios.get(
    `https://api.henrikdev.xyz/valorant/v2/mmr/${region}/${encodeURIComponent(name)}/${encodeURIComponent(tag)}`,
    { timeout: 15_000 }
  );
  return res.data?.data;
}

function init(client) {
  client.on('interactionCreate', async i => {
    if (!i.isChatInputCommand() || i.commandName !== 'stats') return;
    await i.deferReply();

    const sub = i.options.getSubcommand();

    try {
      if (sub === 'fortnite') {
        const username = i.options.getString('username');
        const platform = i.options.getString('platform') ?? 'epic';
        const data     = await fortniteStats(username, platform);

        if (!data) return i.editReply('❌ Player not found or stats are set to private.');

        const all = data.stats?.all?.overall ?? {};
        const embed = new EmbedBuilder()
          .setColor(0x5865f2)
          .setTitle(`🎮 Fortnite — ${data.account?.name ?? username}`)
          .setThumbnail(data.image ?? null)
          .addFields(
            { name: '🏆 Wins',    value: String(all.wins    ?? 0),              inline: true },
            { name: '💀 Kills',   value: String(all.kills   ?? 0),              inline: true },
            { name: '☠️ Deaths',  value: String(all.deaths  ?? 0),              inline: true },
            { name: '📈 K/D',     value: (all.kd      ?? 0).toFixed(2),         inline: true },
            { name: '🎯 Win%',    value: `${(all.winRate ?? 0).toFixed(1)}%`,   inline: true },
            { name: '🔢 Matches', value: String(all.matches ?? 0),              inline: true },
            { name: '🎖️ Top 3',  value: String(all.top3    ?? 0),              inline: true },
            { name: '⏱️ Played',  value: all.minutesPlayed
              ? `${Math.round(all.minutesPlayed / 60)}h`
              : 'N/A',                                                           inline: true },
          )
          .setFooter({ text: `Platform: ${platform.toUpperCase()} • fortnite-api.com` })
          .setTimestamp();

        return i.editReply({ embeds: [embed] });
      }

      if (sub === 'valorant') {
        const riotId = i.options.getString('username');
        const region = i.options.getString('region') ?? 'eu';
        const data   = await valorantStats(riotId, region);

        if (!data) return i.editReply('❌ Player not found.');

        const rankImg = data.images?.large ?? null;
        const embed   = new EmbedBuilder()
          .setColor(0xff4655)
          .setTitle(`🎮 Valorant — ${riotId}`)
          .setThumbnail(rankImg)
          .addFields(
            { name: '🏅 Current Rank', value: data.currenttierpatched ?? 'Unranked',          inline: true  },
            { name: '🔢 RR',           value: String(data.ranking_in_tier ?? 0),               inline: true  },
            { name: '📊 Peak Rank',    value: data.highest_rank?.patched_tier ?? 'N/A',        inline: true  },
            { name: '🌍 Region',       value: region.toUpperCase(),                             inline: true  },
            { name: '🆔 PUUID',        value: data.puuid ? `\`${data.puuid.slice(0,12)}…\`` : 'N/A', inline: true },
          )
          .setFooter({ text: 'henrikdev.xyz/valorant' })
          .setTimestamp();

        return i.editReply({ embeds: [embed] });
      }
    } catch (e) {
      console.error('[stats]', e.message);
      return i.editReply(`❌ ${e.message}`);
    }
  });
}

module.exports = { commands, init };
