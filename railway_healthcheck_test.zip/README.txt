Railway health-check test service

This is a minimal HTTP-only test service; it contains no Discord bot or moderation/raid commands.

Deploy instructions:
1. Deploy this folder as its own Railway service.
2. Set the start command to: python app.py
3. Set the Railway healthcheck path to: /health
4. After deployment, open https://YOUR-RAILWAY-DOMAIN/health
5. Expected response: {"status": "healthy"}

The app listens on Railway's PORT environment variable, falling back to 8080 for local testing.
No requirements.txt is needed; it uses only the Python standard library.
